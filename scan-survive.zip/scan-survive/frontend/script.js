const API_BASE = "http://localhost:5000/api"; // Update if hosted on a server

// 🟢 Generate AI Challenge
function generateChallenge() {
    const playerName = document.getElementById("playerName").value.trim();
    const objects = document.getElementById("objects").value.trim();

    if (!playerName || !objects) {
        alert("Please enter your name and at least one object!");
        return;
    }

    fetch(`${API_BASE}/generate-challenge`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerName, objects: objects.split(",") })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert("Error: " + data.error);
        } else {
            document.getElementById("challengeText").innerText = data.challenge;
            document.getElementById("completeChallengeBtn").disabled = false;
        }
    })
    .catch(error => console.error("Error:", error));
}

// 🟢 Complete Challenge
function completeChallenge() {
    const playerName = document.getElementById("playerName").value.trim();

    if (!playerName) {
        alert("Please enter your name first!");
        return;
    }

    fetch(`${API_BASE}/complete-challenge`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert("Error: " + data.error);
        } else {
            alert("Challenge completed! 🎉 Score Updated!");
            fetchLeaderboard(); // Refresh leaderboard
        }
    })
    .catch(error => console.error("Error:", error));
}

// 🟢 Fetch Leaderboard
function fetchLeaderboard() {
    fetch(`${API_BASE}/leaderboard`)
    .then(response => response.json())
    .then(players => {
        const leaderboard = document.getElementById("leaderboard");
        leaderboard.innerHTML = ""; // Clear existing list
        players.forEach(player => {
            const li = document.createElement("li");
            li.textContent = `${player.name}: ${player.score} points`;
            leaderboard.appendChild(li);
        });
    })
    .catch(error => console.error("Error fetching leaderboard:", error));
}

// Load leaderboard on page load
fetchLeaderboard();
