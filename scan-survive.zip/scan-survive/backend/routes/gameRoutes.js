const express = require("express");
const axios = require("axios");
const Player = require("../models/player");

const router = express.Router();

// Test route
router.get("/", (req, res) => {
    res.send("🎮 Game API is working!");
});

// Fetch all players
router.get("/players", async (req, res) => {
    try {
        const players = await Player.findAll();
        res.json(players);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch players" });
    }
});

// Add a new player
router.post("/players", async (req, res) => {
    try {
        const { name } = req.body;
        const newPlayer = await Player.create({ name });
        res.status(201).json(newPlayer);
    } catch (error) {
        res.status(400).json({ error: "Failed to create player" });
    }
});

// Generate AI Challenge
router.post("/generate-challenge", async (req, res) => {
    const { playerName, objects } = req.body;

    if (!playerName || !objects || objects.length === 0) {
        return res.status(400).json({ error: "Player name and objects are required!" });
    }

    const prompt = `User has these objects: ${objects.join(", ")}. Create a survival scenario.`;

    try {
        const response = await axios.post(
            "https://api.openai.com/v1/chat/completions",
            {
                model: "gpt-4",
                messages: [{ role: "user", content: prompt }],
            },
            {
                headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
            }
        );

        const challenge = response.data.choices[0].message.content;

        let player = await Player.findOne({ where: { name: playerName } });

        if (!player) {
            player = await Player.create({ name: playerName });
        }

        player.lastChallenge = challenge;
        await player.save();

        res.json({ challenge });
    } catch (error) {
        console.error("Error generating AI challenge:", error);
        res.status(500).json({ error: "AI Challenge generation failed!" });
    }
});

// Complete Challenge & Update Score
router.post("/complete-challenge", async (req, res) => {
    const { playerName } = req.body;

    if (!playerName) {
        return res.status(400).json({ error: "Player name is required!" });
    }

    let player = await Player.findOne({ where: { name: playerName } });

    if (!player) return res.status(404).json({ error: "Player not found" });

    player.challengesCompleted += 1;
    player.score += 100;
    await player.save();

    res.json({ message: "Challenge completed!", player });
});

// Get Leaderboard
router.get("/leaderboard", async (req, res) => {
    try {
        const players = await Player.findAll({ order: [["score", "DESC"]], limit: 10 });
        res.json(players);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
});

module.exports = router;

