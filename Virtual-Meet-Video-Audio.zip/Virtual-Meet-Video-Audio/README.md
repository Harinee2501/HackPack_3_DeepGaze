# Virtual-Meet-Video-Audio
Using socket.io as signaling server and communicate between participants using WebRTC (Video and audio communication)
