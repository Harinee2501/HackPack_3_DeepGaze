print("WELCOME TO PLANZ")
print("OUR APP LETS YOU CONVIENENTLY PLAN YOUR STUDY TIME ! ")
print("INSTRUCTIONS:-")
print("1.MAXIMUM ALLOWED SUBJECTS IS 5")
print("2.PLEASE ARRANGE THE SUBJECTS ACCORDING TO THE DIFFICULTY OF THE SUBJECTS STARTING FROM THE MOST DIFFICULT")
h=int(input("Enter the number of minutes you would like to study: "))
s=int(input("Enter the number of subjects: "))
if s==1:
    s1=input("Enter subject 1: ")
    print("The amount of time dedicated to study",s1,"is",h,"minutes")
    print("THANK YOU FOR USING OUR APP!\n REMEMBER, HARDWORK NEVER FAILS =)")
if s==2:
    s1=input("Enter subject 1: ")
    s2=input("Enter subject 2: ")
    times1=70*h//100
    times2=30*h//100
    print("Amount of time dedicated for",s1,"is",times1,"minutes")
    print("Amount of time dedicated for",s2,"is",times2,"minutes")
    print("THANK YOU FOR USING OUR APP!\n REMEMBER, HARDWORK NEVER FAILS =)")
if s==3:
    s1=input("Enter subject 1: ")
    s2=input("Enter subject 2: ")
    s3=input("Enter subject 3: ")
    times1=45*h//100
    times2=30*h//100
    times3=25*h//100
    print("Amount of time dedicated for",s1,"is",times1,"minutes")
    print("Amount of time dedicated for",s2,"is",times2,"minutes")
    print("Amount of time dedicated for",s3,"is",times3,"minutes")
    print("THANK YOU FOR USING OUR APP!\n REMEMBER, HARDWORK NEVER FAILS =)")
if s==4:
    s1=input("Enter subject 1: ")
    s2=input("Enter subject 2: ")
    s3=input("Enter subject 3: ")
    s4=input("Enter subject 4: ")
    times1=35*h//100
    times2=30*h//100
    times3=20*h//100
    times4=15*h//100
    print("Amount of time dedicated for",s1,"is",times1,"minutes")
    print("Amount of time dedicated for",s2,"is",times2,"minutes")
    print("Amount of time dedicated for",s3,"is",times3,"minutes")
    print("Amount of time dedicated for",s4,"is",times4,"minutes")
    print("THANK YOU FOR USING OUR APP!\n REMEMBER, HARDWORK NEVER FAILS =)")
if s==5:
    s1=input("Enter subject 1: ")
    s2=input("Enter subject 2: ")
    s3=input("Enter subject 3: ")
    s4=input("Enter subject 4: ")
    s5=input("Enter subject 5: ")
    times1=30*h//100
    times2=25*h//100
    times3=20*h//100
    times4=15*h//100
    times5=10*h//100
    print("Amount of time dedicated for",s1,"is",times1,"minutes")
    print("Amount of time dedicated for",s2,"is",times2,"minutes")
    print("Amount of time dedicated for",s3,"is",times3,"minutes")
    print("Amount of time dedicated for",s4,"is",times4,"minutes")
    print("Amount of time dedicated for",s5,"is",times5,"minutes")
    print("THANK YOU FOR USING OUR APP!\n REMEMBER, HARDWORK NEVER FAILS =)")  
if s>5:
    print("Error! Only a maximum of 5 subjects is allowed.\n Please try again") 
